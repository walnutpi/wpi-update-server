import _aw_isp
import os
from pathlib import Path


def __exit_if_video_device_error(video_index: int = 0):
    # 打开文件/sys/class/video4linux/video0/name，判断是不是以vin_video开头
    video_dev_path = f"/dev/video{video_index}"
    video_name_path = f"/sys/class/video4linux/video{video_index}/name"

    if not os.path.exists(video_dev_path):
        print("\nisp error")
        print(f"Video device does not exist: {video_dev_path}")
        print(f"摄像头设备不存在: {video_dev_path}")
        print("\n")
        exit(-1)

    if not os.path.exists(video_name_path):
        print("\nisp error")
        print(f"Video device does not exist: {video_name_path}")
        print(f"摄像头配置文件不存在: {video_name_path}")
        print("\n")
        exit(-1)

    with open(video_name_path, "r") as f:
        video_name = f.read().strip()
    if not video_name.startswith("vin_video"):
        print("\nisp error")
        print(f"usb camera{video_index} can not use isp: {video_name}")
        print(f"usb摄像头{video_index}无法使用isp: {video_name}")
        print("\n")
        exit(-1)

    if not os.path.exists("/dev/media0"):
        print("\nisp error")
        print("isp device does not exist: /dev/media0")
        print("isp设备不存在: /dev/media0")
        print("\n")
        exit(-1)

    st = Path("/dev/media0").stat()
    major, minor = st.st_rdev >> 8, st.st_rdev & 0xFF
    model = Path(f"/sys/dev/char/{major}:{minor}/model")
    if not model.exists():
        print(f"{model} does not exist")
        exit(-1)
    # 判断文件内容是否以 Allwinner 开头
    with open(model, "r") as f:
        content = f.read().strip()
        if not content.startswith("Allwinner"):
            print("\nisp error")
            print(
                f"Please make sure the mipi camera is the only camera when the system boots, please connect usb camera after the system is turned on."
            )
            print(f"请确保mipi摄像头是开机时唯一的摄像头，如需使用usb摄像头请开机完成后再连接")
            print("\n")
            exit(-1)


def start(camera=0):
    __exit_if_video_device_error(camera)
    ret = _aw_isp.start(camera)
    if ret:
        print("isp start success")
    else:
        print("isp start failed")
        exit(-1)
