import cv2
import numpy as np
import os
import time

os.environ["DISPLAY"] = ":0.0"
import walnutpi_isp


if __name__ == "__main__":
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter.fourcc("N", "V", "1", "2"))
    walnutpi_isp.start(camera=0)
    # cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    # cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

    if not cap.isOpened():
        print("摄像头初始化失败")
        exit()

    print(f"实际宽度: {cap.get(cv2.CAP_PROP_FRAME_WIDTH)}")
    print(f"实际高度: {cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}")
    print(f"实际FPS: {cap.get(cv2.CAP_PROP_FPS)}")

    print("开始读取摄像头图像...")
    while True:
        ret, frame = cap.read()
        if ret:
            cv2.imshow("Image", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
        else:
            print("无法读取摄像头图像")
            break
    cap.release()
    cv2.destroyAllWindows()
