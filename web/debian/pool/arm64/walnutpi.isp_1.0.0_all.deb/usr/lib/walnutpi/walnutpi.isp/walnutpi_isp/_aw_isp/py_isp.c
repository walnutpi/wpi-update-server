#include <Python.h>
#include <structmember.h>
#include <pthread.h>
#include "AWIspApi.h"
#include <fcntl.h>
#include <unistd.h>

typedef struct
{
    int isp_id;
    AWIspApi *isp;  // 添加 isp 指针
} thread_args_t;

void *isp_thread(void *arg)
{
    thread_args_t *args = (thread_args_t *)arg;
    int isp_id = args->isp_id;
    AWIspApi *isp = args->isp;

    int ret = 0;
    ret = isp->ispStart(isp_id);
    if (ret < 0)
    {
        printf("isp start err!\n");
    }

    isp->ispWaitToExit(isp_id);
    isp->ispApiUnInit();
    DestroyAWIspApi(isp);

    free(args);
    return NULL;
}

static PyObject *aw_isp_start(PyObject *self, PyObject *args)
{
    int video_id;

    if (!PyArg_ParseTuple(args, "i", &video_id))
        Py_RETURN_FALSE;
    AWIspApi *isp;
    isp = CreateAWIspApi();
    isp->ispApiInit();
    int isp_id = isp->ispGetIspId(video_id);
    if(isp_id < 0)
        Py_RETURN_FALSE;

    
    thread_args_t *thread_args = malloc(sizeof(thread_args_t));
    if (!thread_args)
    {
        PyErr_SetString(PyExc_MemoryError, "Failed to allocate memory for thread arguments");
        Py_RETURN_FALSE;
    }
    thread_args->isp_id = isp_id;
    thread_args->isp = isp;

    // 创建线程
    pthread_t thread;
    int result = pthread_create(&thread, NULL, isp_thread, thread_args);
    if (result != 0)
    {
        free(thread_args);
        PyErr_SetString(PyExc_RuntimeError, "Failed to create thread");
        Py_RETURN_FALSE;
    }

    // 分离线程，让系统自动回收资源
    pthread_detach(thread);

    Py_RETURN_TRUE;
}

static PyMethodDef AwIspMethods[] = {

    {"start", aw_isp_start, METH_VARARGS,
     "Start ISP in a new thread with a number parameter"},
    {NULL, NULL, 0, NULL}};

static struct PyModuleDef aw_isp_module = {
    PyModuleDef_HEAD_INIT,
    "_aw_isp",                        // 模块名
    "Allwinner ISP Python Extension", // 模块文档字符串
    -1,                               // 模块保持状态的大小
    AwIspMethods                      // 模块方法
};

PyMODINIT_FUNC PyInit__aw_isp(void)
{
    return PyModule_Create(&aw_isp_module);
}